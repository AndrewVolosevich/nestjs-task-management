export interface JwtPayloadInterface {
  username: string
}